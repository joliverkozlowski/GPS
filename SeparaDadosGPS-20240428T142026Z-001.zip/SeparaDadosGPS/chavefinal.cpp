#include<stdio.h>

int main() {
  // Dados:

//time - - lat - lon - Fix - Nsat - Hdilution - H
//$GPGGA,163008.20,3256.56419,N,10654.88732,W,1,09,1.25,1386.5,M,-25.6,M,,*57
//$GPGGA,,,,,,0,00,99.99,,,,,,*48
//012345678901234567890123456789012345678901234567890123456789012345678901234
//0---------1---------2---------3---------4---------5---------6---------7----
//time - Status - lat - lon - Speed
//$GPRMC,163008.30,A,3256.56418,N,10654.88733,W,0.053,,210618,,,A*6A
//012345678901234567890123456789012345678901234567890123456789012345678901234
//0---------1---------2---------3---------4---------5---------6---------7----
  char NMEA1 [81];                   //Variable for first NMEA sentence
  char NMEA2 [81];                   //Variable for second NMEA sentence
  char c, Status;                   //to read characters coming from the GPS and status
  char horario [10];
  char lat [12];                   // latitude
  char lon [12];                   // longitude
  char sinalat, sinalon;
  char Speed[10];                     // velocidade
  char Nsat[3];                   // numero de satelites
  char Hdilution [8];             // dilui��o horizontal
  char H [12];                    // altura
  char fix;                       //Fix quality
  int i, j, t;                      // contadores

  gets(NMEA1); //EXEMPLO: $GPGGA,163008.20,3256.56419,N,10654.88732,W,1,09,1.25,1386.5,M,-25.6,M,,*57
  i=7;
  j=i;
  c = NMEA1[i];
  t=0;
  while(c != ',' && t<15)                      /// Enquanto n�o for lida a pr�xima v�rgula
  {
    horario[i-7] = c;
    i++;
    c = NMEA1[i];
    t++;
  }
  horario[i-j]= '\0';
  i++;
  j=i;
  c = NMEA1[i];
   t=0;
  while(c != ',' && t<15)                      /// Enquanto n�o for lida a pr�xima v�rgula
  {
    lat[i-j] = c;
    i++;
    c = NMEA1[i];
    t++;
  }
  t=0;
  lat[i-j] = '\0';
  i++;
  c = NMEA1[i];
  while(c != ',' && t<4)
  {
     sinalat = c;
     i++;
     c = NMEA1[i];
     t++;
  }
    i++;
    j=i;
   c = NMEA1[i];
   t=0;
    while(c != ',' && t<15)   /// Enquanto n�o for lida a pr�xima v�rgula
  {
    lon[i-j] = c;
    i++;
    c = NMEA1[i];
    t++;
  }
  t=0;
  lon[i-j] = '\0';
  i++;
  c = NMEA1[i];
  while(c != ',' && t<4)
  {
     sinalon = c;
     i++;
     c = NMEA1[i];
     t++;
  }
  t=0;
  i++;
  c = NMEA1[i];
  fix = c;
  i=i+2;
  Nsat[0] = NMEA1[i];
  i++;
  Nsat[1] = NMEA1[i];
  Nsat[2] = '\0';
  i=i+2;
  j = i;
  c = NMEA1[i];
  t=0;
  while(c != ',' && t<15)      /// Enquanto n�o for lida a pr�xima v�rgula
  {
    Hdilution[i-j] = c;
    i++;
    c = NMEA1[i];
    t++;
  }
  Hdilution[i-j] = '\0';
  i++;
  c = NMEA1[i] ;
  j=i;
   t=0;
  while(c != ',' && t<15)   /// Enquanto n�o for lida a pr�xima v�rgula
  {
    H[i-j] = c;
    i++;
    c = NMEA1[i];
    t++;
  }
  H[i-j] = '\0';

  //TESTE
  printf("\n\n Horario:   %s", horario);
  printf("\n Lat:       %s %c", lat, sinalat);
  printf("\n Lon:       %s %c", lon, sinalon);
  printf("\n %c", fix);
  printf("\n Nsat:      %s", Nsat);
  printf("\n Hdilution: %s", Hdilution);
  printf("\n Altura:    %s \n\n", H);


  /*---------------------------------------------------- SEGUNDA PARTE ----------------------------------------------------------------------*/
  gets(NMEA2); //EXEMPLO: $GPRMC,163008.30,A,3256.56418,N,10654.88733,W,0.053,,210618,,,A*6A
  i=7;
  j=i;
 c = NMEA2[i];
  t=0;
  while(c != ',' && t<15)                      /// Enquanto n�o for lida a pr�xima v�rgula
  {
    horario[i-j] = c;
    i++;
    c = NMEA2[i];
    t++;
  }
  horario[i-j]='\0';
  i++;
  Status=NMEA2[i];
  i=i+2;
  j=i;
  c = NMEA2[i];
  t=0;
  while(c != ',' && t<15)                      /// Enquanto n�o for lida a pr�xima v�rgula
  {
    lat[i-j] = c;
    i++;
    c = NMEA2[i];
    t++;
  }
  t=0;
  lat[i-j] = '\0';
  i++;
  c = NMEA2[i];
  while(c != ',' && t<4)
  {
     sinalat = c;
     i++;
     c = NMEA2[i];
     t++;
  }
  if(t==0)
  sinalat = '\0';
  i++;
  j=i;
  c = NMEA2[i];
  t=0;
    while(c != ',' && t<15)   /// Enquanto n�o for lida a pr�xima v�rgula
  {
    lon[i-j] = c;
    i++;
    c = NMEA2[i];
    t++;
  }
  lon[i-j] = '\0';
  i++;
  c = NMEA2[i];
  while(c != ',' && t<15)
  {
     sinalon = c;
     i++;
     c = NMEA1[i];
     t++;
  }
  if(t==0)
  sinalon = '\0';
  i++;
  j=i;
  c = NMEA2[i];
   t=0;
    while(c != ',' && t<15)   /// Enquanto n�o for lida a pr�xima v�rgula
  {
    Speed[i-j] = c;
    i++;
    c = NMEA2[i];
    t++;
  }
   t=0;
  Speed[i-j] = '\0';
    //TESTE
  printf("\n\n Horario:    %s", horario);
  printf("\n Status:     %c", Status);
  printf("\n Lat:        %s %c", lat, sinalat);
  printf("\n Lon:        %s %c", lon, sinalon);
  printf("\n Velocidade: %s  \n\n", Speed);
  return 0;
  }


